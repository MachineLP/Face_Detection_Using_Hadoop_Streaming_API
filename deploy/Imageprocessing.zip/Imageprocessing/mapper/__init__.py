from FaceDetectorMapper import Mapper
